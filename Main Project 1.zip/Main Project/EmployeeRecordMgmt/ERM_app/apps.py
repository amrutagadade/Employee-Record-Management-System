from django.apps import AppConfig


class ErmAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ERM_app'
